
  <style>
  #title {
    padding-top: 40%;
    font-size: 96px;
  }

  #subtitle {
    font-size: 36px;
    padding-top: 18%;
  }

  #ending {
    padding-top: 60%;
    font-size: 48px;
    padding-bottom: 12%;
  }

  .center {
    text-align: center;
  }
  .right {
    text-align: right;
  }

  #inform {
    padding-right: 8%;
    font-size: 18px;
  }

  #allinform {
    padding-top: 18%;
  }

  .topic {
    padding-top: 12%;
    padding-bottom: 8%;
    font-size: 48px;
  }
</style>
<div class="center">
  <div id="title">{{ printTitle }}</div>
  <div id="subtitle" v-if="documentTitle !== printTitle">{{ documentTitle }}</div>
</div>
<div class="right" id="allinform">
  <p id="inform">姓名：________________</p>
  <p id="inform">学号：________________</p>
  <p id="inform">班级：________________</p>
  <p id="inform">学校：________________</p>

  <hr />
  <div>
    {{ printDate }}<br />
    制作：<a href="https://github.com/7086cmd/">7086cmd</a><br />
    仓库地址：<a href="https://github.com/7086cmd/politics-history-summary"
      >https://github.com/7086cmd/politics-history-summary</a
    >
  </div>
</div>


<div class="divider_top"></div>

<div class="divider_top"></div>

<div class="center">
  <div class="topic">目录</div>
</div>

    - [Unit 1 How can we become good learners?](#unit-1-how-can-we-become-good-learners?)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 1 错题](#test-for-unit-1-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>

<div class="divider_top"></div>


### Unit 1 How can we become good learners?

---

#### 全效学习错题

1. 迈克通过使用词典扩大词汇量<br>
   Mike enlarges his vocabulary by <u>using</u> <u>a</u> <u>dictionary</u>.
2. The two girls got lost when they went <u>through</u> the forest.
3. <u>By</u> talking to the robot called CIMON-2, the astronaut won't feel lonely in space.
4. Lucy <u>fell in love with</u> sailing the first time she tried it. She thought it was so exciting. (`fall in love with` `be afraid of`)
5. I like to take down the useful sentences <u>like</u> "It serves you right".
6. It is a good idea to p<u>ronounce</u> new words aloud every day.
7. Mr. Zhang is very glad that his salary <u>increases</u> (增加) a lot every year.
8. Li Ming and I are not only friends but also good study <u>partners</u> (搭档).
9. <u>Reviewing</u> (复习) what you have learned in time is helpful for you to get good grades.

---

#### Test for Unit 1 错题

1. \- Excuse me, could you help me move the bag?<br>
    \- Certainly, <u>it's piece of cake</u>. (`A`)<br>
    A. `It's piece of cake`<br>
    B. `Use it or lose it`<br>
    C. `Practice makes perfect`<br>
    D. `It serves you right`<br>
2.  Tu Youyou won the Nobel Prize for medicine <u>through</u> (凭借) many years of hard work.
3. it's a good habit to read English <u>aloud</u> (大声地) in the morning.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

<script setup>
import { ref } from "vue";

const printTitle = ref(decodeURI(new URL(location.href).pathname.split("/")[1])) ?? "政史地总资料";

const documentTitle = ref(decodeURI(new URL(location.href).pathname.split("/").filter(x => (x !== "" && x !== "print")).join(" | "))) ?? "政史地总资料";

const printDate = ref(`导出日期：${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`);

</script>

# 版权声明

作者: [7086cmd](https://github.com/7086cmd).<br>

<p style="font-size: 24px">
本文遵循 <code>CC BY-NC-SA 4.0</code> 协议。未经允许，请勿擅自改动、商用这些内容，并且若转载请注明出处。
</p>

<div class="center">
  <div id="ending">7086cmd's notes</div>
</div>

<div class="right">
  <p>未经作者许可禁售。</p>
</div>
