### Unit 1 How can we become good learners?

---

#### 全效学习错题

1. 迈克通过使用词典扩大词汇量<br>
   Mike enlarges his vocabulary by <u>using</u> <u>a</u> <u>dictionary</u>.
2. The two girls got lost when they went <u>through</u> the forest.
3. <u>By</u> talking to the robot called CIMON-2, the astronaut won't feel lonely in space.
4. Lucy <u>fell in love with</u> sailing the first time she tried it. She thought it was so exciting. (`fall in love with` `be afraid of`)
5. I like to take down the useful sentences <u>like</u> "It serves you right".
6. It is a good idea to p<u>ronounce</u> new words aloud every day.
7. Mr. Zhang is very glad that his salary <u>increases</u> (增加) a lot every year.
8. Li Ming and I are not only friends but also good study <u>partners</u> (搭档).
9. <u>Reviewing</u> (复习) what you have learned in time is helpful for you to get good grades.

---

#### Test for Unit 1 错题

1. \- Excuse me, could you help me move the bag?<br>
    \- Certainly, <u>it's piece of cake</u>. (`A`)<br>
    A. `It's piece of cake`<br>
    B. `Use it or lose it`<br>
    C. `Practice makes perfect`<br>
    D. `It serves you right`<br>
2.  Tu Youyou won the Nobel Prize for medicine <u>through</u> (凭借) many years of hard work.
3. it's a good habit to read English <u>aloud</u> (大声地) in the morning.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
