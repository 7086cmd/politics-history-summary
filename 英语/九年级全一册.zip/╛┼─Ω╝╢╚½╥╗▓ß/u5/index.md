### Unit 5 What are the shirts made of?

---

#### 全效学习错题

1. Sweaters may <u>be produced</u> (produce) in many different ways.
2. Butter is made <u>from</u> milk.
3. It is well-known <u>to</u> most people that Beijing is known as the capital of China.
4. When you visit F<u>rance</u>, you can go to the Eiffel Tower and take photos there.
5. This kind of cars <u>is produced</u> (produce) in China.
6. Students <u>aren't allowed</u> to take smartphones to school.
7. Those terrible accidents <u>were caused</u> by the careless drivers last year.
8. Jack usually washes the car on Sunday.<br>
   The car <u>is</u> usually washed by Jack on Sunday.
9. 看看哪只风筝飞得最高是件很有趣的事情。<br>
   It's really fun to <u>see</u> which kite flies the highest.
10. The water can be h<u>eated</u> to become gas.
11. I can't play soccer with you now because I have to c<u>omplete</u> my homework first.
12. Jane tries to avoid <u>meeting</u> (meet) her cousin because he always makes her bored.
13. Most of the <u>products</u> (product) are American products, but they are made in China.
14. Usually, the most common things can <u>be turned into</u> (`turn info`) objects of beauty.
15. Weifang, a city in Shandong Province, <u>has been known for</u> (`be known for`) making kites _since_ over 2,000 years ago.

---

#### Test for Unit 5 错题

1. The telephone was invented <u>in 1876</u>. (划线提问)<br>
    <u>When</u> was the telephone invented?

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
