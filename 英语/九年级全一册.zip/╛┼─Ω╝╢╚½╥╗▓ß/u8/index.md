### Unit 8 It must belong to Carla.

---

#### 全效学习错题

1. The <u>rabbits</u> (野兔) ran into the forest and the hunter couldn't find them.
2. The little girl doesn't feel like talking. She hopes they can s<u>imply</u> leave her alone.
3. The dog is having fun <u>creating</u> (create) a terrible mess in the next room!
4. I <u>had no idea</u> who took away my bag. I couldn't find it anywhere.
5. The teacher didn't understand why the pupil had so many <u>strange</u> (奇怪的) questions.
6. Red s<u>uits</u> you. You should wear red clothes more often.
7. The plane <u>landed</u> (着陆) at the international airport ten minutes ago.
8. Look! My dog is running a a<u>fter</u> a mouse.
9. It's very neccessary for us to wash hands, expecially during the special <u>period</u>.
10. All the children will have fun <u>helping</u> the farmers with the farm work.

---

#### Test for Unit 8 错题

1. _A <u>Midsummer</u> (仲夏) Night's Dream_ is one of the comic masterpieces of Shakespeare.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
