
  <style>
  #title {
    padding-top: 40%;
    font-size: 96px;
  }

  #subtitle {
    font-size: 36px;
    padding-top: 18%;
  }

  #ending {
    padding-top: 60%;
    font-size: 48px;
    padding-bottom: 12%;
  }

  .center {
    text-align: center;
  }
  .right {
    text-align: right;
  }

  #inform {
    padding-right: 8%;
    font-size: 18px;
  }

  #allinform {
    padding-top: 18%;
  }

  .topic {
    padding-top: 12%;
    padding-bottom: 8%;
    font-size: 48px;
  }
</style>
<div class="center">
  <div id="title">{{ printTitle }}</div>
  <div id="subtitle" v-if="documentTitle !== printTitle">{{ documentTitle }}</div>
</div>
<div class="right" id="allinform">
  <p id="inform">姓名：________________</p>
  <p id="inform">学号：________________</p>
  <p id="inform">班级：________________</p>
  <p id="inform">学校：________________</p>

  <hr />
  <div>
    {{ printDate }}<br />
    制作：<a href="https://github.com/7086cmd/">7086cmd</a><br />
    仓库地址：<a href="https://github.com/7086cmd/politics-history-summary"
      >https://github.com/7086cmd/politics-history-summary</a
    >
  </div>
</div>


<div class="divider_top"></div>

<div class="divider_top"></div>

<div class="center">
  <div class="topic">目录</div>
</div>

    - [Unit 4 I used to be afraid of the dark.](#unit-4-i-used-to-be-afraid-of-the-dark.)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 4 错题](#test-for-unit-4-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>

<div class="divider_top"></div>


### Unit 4 I used to be afraid of the dark.

---

#### 全效学习错题

1. Neither Anna nor I <u>am interested in</u> (be interested in) history because we think it's boring.
2. Judy d<u>ared</u> to live in a house alone, and she wasn't afraid.
3. American English is different from B<u>ritish</u> English in pronunciation and spelling.
4. Jim never got to work late, <u>did</u> <u>Jane</u>? (完成反意疑问句)
5. I am old enough and I can wear w<u>hatever</u> I like.
6. Our parents take p<u>ride</u> in everything good we do.
7. My parents are always <u>thinking of</u> me even though they are busy with their work.
8. The road to <u>success</u> (succeed) is always difficult. So don't give up until you make your dream come true.
9. Mr. White doesn't know whether his son <u>has dealt with</u> (`deal with`) the problem so far.

---

#### Test for Unit 4 错题

1. I think we need to improve our educational system in <u>general</u> (总的).
2. The teacher <u>advised</u> (建议) the parents to talk with the kid in person.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

<script setup>
import { ref } from "vue";

const printTitle = ref(decodeURI(new URL(location.href).pathname.split("/")[1])) ?? "政史地总资料";

const documentTitle = ref(decodeURI(new URL(location.href).pathname.split("/").filter(x => (x !== "" && x !== "print")).join(" | "))) ?? "政史地总资料";

const printDate = ref(`导出日期：${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`);

</script>

# 版权声明

作者: [7086cmd](https://github.com/7086cmd).<br>

<p style="font-size: 24px">
本文遵循 <code>CC BY-NC-SA 4.0</code> 协议。未经允许，请勿擅自改动、商用这些内容，并且若转载请注明出处。
</p>

<div class="center">
  <div id="ending">7086cmd's notes</div>
</div>

<div class="right">
  <p>未经作者许可禁售。</p>
</div>
