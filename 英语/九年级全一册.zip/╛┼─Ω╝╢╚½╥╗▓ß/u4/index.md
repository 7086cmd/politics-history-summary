### Unit 4 I used to be afraid of the dark.

---

#### 全效学习错题

1. Neither Anna nor I <u>am interested in</u> (be interested in) history because we think it's boring.
2. Judy d<u>ared</u> to live in a house alone, and she wasn't afraid.
3. American English is different from B<u>ritish</u> English in pronunciation and spelling.
4. Jim never got to work late, <u>did</u> <u>Jane</u>? (完成反意疑问句)
5. I am old enough and I can wear w<u>hatever</u> I like.
6. Our parents take p<u>ride</u> in everything good we do.
7. My parents are always <u>thinking of</u> me even though they are busy with their work.
8. The road to <u>success</u> (succeed) is always difficult. So don't give up until you make your dream come true.
9. Mr. White doesn't know whether his son <u>has dealt with</u> (`deal with`) the problem so far.

---

#### Test for Unit 4 错题

1. I think we need to improve our educational system in <u>general</u> (总的).
2. The teacher <u>advised</u> (建议) the parents to talk with the kid in person.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
