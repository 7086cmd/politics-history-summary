### Unit 9 I like music that I can dance to.

---

#### 全效学习错题

1. I <u>suppose</u> (推断) they will come here by bus tommorrow.
2. On such a rainy day, I prefer <u>to stay</u> at home rather than go to the movies.
3. What about books that give us something <u>to think</u> about?
4. With these words, he s<u>hut</u> the door heavily and left angrily.
5. I can <u>shut off</u> my brain when I see comedies and cartoons which I love best. (`shut off`, `stick to`)
6. Teachers always say that the best way to achieve dreams is <u>sticking to</u> anything about dreams.
7. I like the gift because it is useful and <u>inexpensive</u> (expensive).
8. Michael, do you think your brother can get a movie poster <u>for</u> me?
9. The brave soilder got <u>wounded</u> (受伤) in that war and was praised.
10. He is only student <u>that</u> knows the answer.
11. My sister is always busy. She goes to the movies <u>once in a while</u>.

---

#### Test for Unit 9 错题

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
