
  <style>
  #title {
    padding-top: 40%;
    font-size: 96px;
  }

  #subtitle {
    font-size: 36px;
    padding-top: 18%;
  }

  #ending {
    padding-top: 60%;
    font-size: 48px;
    padding-bottom: 12%;
  }

  .center {
    text-align: center;
  }
  .right {
    text-align: right;
  }

  #inform {
    padding-right: 8%;
    font-size: 18px;
  }

  #allinform {
    padding-top: 18%;
  }

  .topic {
    padding-top: 12%;
    padding-bottom: 8%;
    font-size: 48px;
  }
</style>
<div class="center">
  <div id="title">{{ printTitle }}</div>
  <div id="subtitle" v-if="documentTitle !== printTitle">{{ documentTitle }}</div>
</div>
<div class="right" id="allinform">
  <p id="inform">姓名：________________</p>
  <p id="inform">学号：________________</p>
  <p id="inform">班级：________________</p>
  <p id="inform">学校：________________</p>

  <hr />
  <div>
    {{ printDate }}<br />
    制作：<a href="https://github.com/7086cmd/">7086cmd</a><br />
    仓库地址：<a href="https://github.com/7086cmd/politics-history-summary"
      >https://github.com/7086cmd/politics-history-summary</a
    >
  </div>
</div>


<div class="divider_top"></div>

<div class="divider_top"></div>

<div class="center">
  <div class="topic">目录</div>
</div>

    - [Unit 2 I think that mooncakes are delicious!](#unit-2-i-think-that-mooncakes-are-delicious!)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 2 错题](#test-for-unit-2-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>

<div class="divider_top"></div>


### Unit 2 I think that mooncakes are delicious!

---

#### 全效学习错题

1. What does your father like best <u>about</u> the Lantern Festival?
2. How lucky you are! You can eat what you like but you never put <u>on</u> weight.
3. There is nothing on the table. You may <u>lay</u> (放置) anything you like to eat on it.
4. The Chinese enjoy the tradition of a<u>dmiring</u> the full moon on the Mid-Autumn night.
5. I found that someone <u>stole</u> (steal) something from my room last night.
6. He <u>flew</u> (fly) a kite with his friends in the park yesterday.
7. Liu Mei swims well and she is a <u>fantastic</u> (极好的) swimmer.
8. Mrs. Smart always w<u>arns</u> her students not to stay out late at night.

---

#### Test for Unit 2 错题

1. He <u>used to</u> go out with his parents, but now he <u>is used to</u> staying at home alone. (`A`)<br>
    A. `used to`; `is used to`<br>
    B. `is used to`; `used to`<br>
    C. `use to`; `is used to`<br>
    D. `use to`; `used to`<br>

2. Kitty asks <u>whether</u> there will <u>be snow</u> this winter. (`D`)<br>
    A. `if`; `be snowy`<br>
    B. `whether`; `have snow`<br>
    C. `that`; `have snow`<br>
    D. `whether`; `be snow`<br>

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

<script setup>
import { ref } from "vue";

const printTitle = ref(decodeURI(new URL(location.href).pathname.split("/")[1])) ?? "政史地总资料";

const documentTitle = ref(decodeURI(new URL(location.href).pathname.split("/").filter(x => (x !== "" && x !== "print")).join(" | "))) ?? "政史地总资料";

const printDate = ref(`导出日期：${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`);

</script>

# 版权声明

作者: [7086cmd](https://github.com/7086cmd).<br>

<p style="font-size: 24px">
本文遵循 <code>CC BY-NC-SA 4.0</code> 协议。未经允许，请勿擅自改动、商用这些内容，并且若转载请注明出处。
</p>

<div class="center">
  <div id="ending">7086cmd's notes</div>
</div>

<div class="right">
  <p>未经作者许可禁售。</p>
</div>
