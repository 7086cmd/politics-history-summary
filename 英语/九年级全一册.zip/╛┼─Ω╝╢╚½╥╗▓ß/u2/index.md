### Unit 2 I think that mooncakes are delicious!

---

#### 全效学习错题

1. What does your father like best <u>about</u> the Lantern Festival?
2. How lucky you are! You can eat what you like but you never put <u>on</u> weight.
3. There is nothing on the table. You may <u>lay</u> (放置) anything you like to eat on it.
4. The Chinese enjoy the tradition of a<u>dmiring</u> the full moon on the Mid-Autumn night.
5. I found that someone <u>stole</u> (steal) something from my room last night.
6. He <u>flew</u> (fly) a kite with his friends in the park yesterday.
7. Liu Mei swims well and she is a <u>fantastic</u> (极好的) swimmer.
8. Mrs. Smart always w<u>arns</u> her students not to stay out late at night.

---

#### Test for Unit 2 错题

1. He <u>used to</u> go out with his parents, but now he <u>is used to</u> staying at home alone. (`A`)<br>
    A. `used to`; `is used to`<br>
    B. `is used to`; `used to`<br>
    C. `use to`; `is used to`<br>
    D. `use to`; `used to`<br>

2. Kitty asks <u>whether</u> there will <u>be snow</u> this winter. (`D`)<br>
    A. `if`; `be snowy`<br>
    B. `whether`; `have snow`<br>
    C. `that`; `have snow`<br>
    D. `whether`; `be snow`<br>

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
