
  <style>
  #title {
    padding-top: 40%;
    font-size: 96px;
  }

  #subtitle {
    font-size: 36px;
    padding-top: 18%;
  }

  #ending {
    padding-top: 60%;
    font-size: 48px;
    padding-bottom: 12%;
  }

  .center {
    text-align: center;
  }
  .right {
    text-align: right;
  }

  #inform {
    padding-right: 8%;
    font-size: 18px;
  }

  #allinform {
    padding-top: 18%;
  }

  .topic {
    padding-top: 12%;
    padding-bottom: 8%;
    font-size: 48px;
  }
</style>
<div class="center">
  <div id="title">{{ printTitle }}</div>
  <div id="subtitle" v-if="documentTitle !== printTitle">{{ documentTitle }}</div>
</div>
<div class="right" id="allinform">
  <p id="inform">姓名：________________</p>
  <p id="inform">学号：________________</p>
  <p id="inform">班级：________________</p>
  <p id="inform">学校：________________</p>

  <hr />
  <div>
    {{ printDate }}<br />
    制作：<a href="https://github.com/7086cmd/">7086cmd</a><br />
    仓库地址：<a href="https://github.com/7086cmd/politics-history-summary"
      >https://github.com/7086cmd/politics-history-summary</a
    >
  </div>
</div>


<div class="divider_top"></div>

<div class="divider_top"></div>

<div class="center">
  <div class="topic">目录</div>
</div>

  - [九年级全一册](#九年级全一册)<br>
    - [Unit 1 How can we become good learners?](#unit-1-how-can-we-become-good-learners?)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 1 错题](#test-for-unit-1-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>
    - [Unit 2 I think that mooncakes are delicious!](#unit-2-i-think-that-mooncakes-are-delicious!)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 2 错题](#test-for-unit-2-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>
    - [Unit 3 Could you please tell me where are the restrooms are?](#unit-3-could-you-please-tell-me-where-are-the-restrooms-are?)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 3 错题](#test-for-unit-3-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>
    - [Unit 4 I used to be afraid of the dark.](#unit-4-i-used-to-be-afraid-of-the-dark.)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 4 错题](#test-for-unit-4-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>
    - [Unit 5 What are the shirts made of?](#unit-5-what-are-the-shirts-made-of?)<br>
      - [全效学习错题](#全效学习错题)<br>
      - [Test for Unit 5 错题](#test-for-unit-5-错题)<br>
      - [全效·基础循环练错题](#全效·基础循环练错题)<br>
      - [周周清错题](#周周清错题)<br>

<div class="divider_top"></div>


## 九年级全一册

- [Unit 1 How can we become good learners?](./Unit%201%20How%20can%20we%20become%20good%20learners/index.md)
- [Unit 2 I think that mooncakes are delicious!](./Unit%202%20I%20think%20that%20mooncakes%20are%20delicious/index.md)
- [Unit 3 Could you please tell me where are the restrooms are?](./Unit%203%20Could%20you%20please%20tell%20me%20where%20are%20the%20restrooms%20are/index.md)
- [Unit 4 I used to be afraid of the dark.](./Unit%204%20I%20used%20to%20be%20afraid%20of%20the%20dark/index.md)
- [Unit 5 What are the shirts made of?](./Unit%205%20What%20are%20the%20shirts%20made%20of/index.md)
- [Unit 6 When was it invented?](./Unit%206%20When%20was%20it%20invented/index.md)
- [Unit 7 Teenagers should be allowed to choose ther own clothes.](./Unit%207%20Teenagers%20should%20be%20allowed%20to%20choose%20ther%20own%20clothes/index.md)
- [Unit 8 It must belong to Carla.](./Unit%208%20It%20must%20belong%20to%20Carla/index.md)
- [Unit 9 I like music that I can dance to.](./Unit%209%20I%20like%20music%20that%20I%20can%20dance%20to/index.md)
- [Unit 10 You're supposed to shake hands.](./Unit%2010%20You're%20supposed%20to%20shake%20hands/index.md)

<div class="divider"></div>

### Unit 1 How can we become good learners?

---

#### 全效学习错题

1. 迈克通过使用词典扩大词汇量<br>
   Mike enlarges his vocabulary by <u>using</u> <u>a</u> <u>dictionary</u>.
2. The two girls got lost when they went <u>through</u> the forest.
3. <u>By</u> talking to the robot called CIMON-2, the astronaut won't feel lonely in space.
4. Lucy <u>fell in love with</u> sailing the first time she tried it. She thought it was so exciting. (`fall in love with` `be afraid of`)
5. I like to take down the useful sentences <u>like</u> "It serves you right".
6. It is a good idea to p<u>ronounce</u> new words aloud every day.
7. Mr. Zhang is very glad that his salary <u>increases</u> (增加) a lot every year.
8. Li Ming and I are not only friends but also good study <u>partners</u> (搭档).
9. <u>Reviewing</u> (复习) what you have learned in time is helpful for you to get good grades.

---

#### Test for Unit 1 错题

1. \- Excuse me, could you help me move the bag?<br>
    \- Certainly, <u>it's piece of cake</u>. (`A`)<br>
    A. `It's piece of cake`<br>
    B. `Use it or lose it`<br>
    C. `Practice makes perfect`<br>
    D. `It serves you right`<br>
2.  Tu Youyou won the Nobel Prize for medicine <u>through</u> (凭借) many years of hard work.
3. it's a good habit to read English <u>aloud</u> (大声地) in the morning.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

### Unit 2 I think that mooncakes are delicious!

---

#### 全效学习错题

1. What does your father like best <u>about</u> the Lantern Festival?
2. How lucky you are! You can eat what you like but you never put <u>on</u> weight.
3. There is nothing on the table. You may <u>lay</u> (放置) anything you like to eat on it.
4. The Chinese enjoy the tradition of a<u>dmiring</u> the full moon on the Mid-Autumn night.
5. I found that someone <u>stole</u> (steal) something from my room last night.
6. He <u>flew</u> (fly) a kite with his friends in the park yesterday.
7. Liu Mei swims well and she is a <u>fantastic</u> (极好的) swimmer.
8. Mrs. Smart always w<u>arns</u> her students not to stay out late at night.

---

#### Test for Unit 2 错题

1. He <u>used to</u> go out with his parents, but now he <u>is used to</u> staying at home alone. (`A`)<br>
    A. `used to`; `is used to`<br>
    B. `is used to`; `used to`<br>
    C. `use to`; `is used to`<br>
    D. `use to`; `used to`<br>

2. Kitty asks <u>whether</u> there will <u>be snow</u> this winter. (`D`)<br>
    A. `if`; `be snowy`<br>
    B. `whether`; `have snow`<br>
    C. `that`; `have snow`<br>
    D. `whether`; `be snow`<br>

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

### Unit 3 Could you please tell me where are the restrooms are?

---

#### 全效学习错题

1. I beg your p<u>ardon</u>, sir. How will you deal with the problem?
2. Could you please tell me the way to the post office? I want to buy some <u>stamps</u> (邮票).
3. The doctor s<u>uggests</u> we should eat more vegetables and do sports.
4. The little girl is nervous, so she <u>holds</u> (抓住) her mother's hands wherever they go.
5. When the girl saw the snake, she was very <u>scared</u> (scare).
6. I suggest <u>going</u> (go) to the Fun Times Park this weekend.
7. They <u>mailed</u> (邮寄) letters to their fathers to show thanks to them yesterday.
8. We all know the sum always rises in the e<u>ast</u> every morning.
9. "Why are you late?" the teacher asked him.<br>
   The teacher asked him why he <u>was</u> late.
10. Are there any public washrooms around here? She wanted to know.<br>
    She wanted to know if there <u>were</u> any public washrooms around here.
11. The young man is waiting for his friend at the c<u>orner</u> of Main Street.
12. The clerk s<u>uggests</u> the boy go to Green Land because they have delicious salads.
13. The big supermarket is <u>uncrowded</u> (crowd) on weekdays. Most people are busy with their work.
14. Anderson repeated his <u>request</u> (要求) that we put off the meeting.
15. <u>On their way to</u> (`on one's way to`) the farm，they met their English teacher.
16. More and more people like to buy books on the Internet as the books on the Internet are <u>inexpensive</u> (`expensive`).

---

#### Test for Unit 3 错题

1. \- Where are you going for the coming winter vacation?<br>\- I won't decide on the place <u>until</u> the end of this month. (`A`)<br>A. `until`<br>B. `unless`<br>C. `at`<br>D. `through`
2. \- I am very sad after hearing the earthquake of Yushu. But I don't know <u>what to do</u>.<br>\- You can raise your money to the charity.<br>A. `how I shoud do`<br>B. `how to do`<br>C. `what to do`<br>D. `what should I do`
3. To my surprise, my hometown <u>has changed</u> a lot in the past two years. (`B`)<br>A. `had changed`<br>B. `has changed`<br>C. `have changed`<br>D. `changed`
4. The boy said he often <u>played</u> soccer after school.

---

#### 全效·基础循环练错题

---

#### 周周清错题

<iframe src="./%E5%91%A8%E5%91%A8%E6%B8%85%E9%94%99%E9%A2%98.pdf" frameborder="0" width="100%" type="application/pdf"></iframe>

---

<div class="divider"></div>

### Unit 4 I used to be afraid of the dark.

---

#### 全效学习错题

1. Neither Anna nor I <u>am interested in</u> (be interested in) history because we think it's boring.
2. Judy d<u>ared</u> to live in a house alone, and she wasn't afraid.
3. American English is different from B<u>ritish</u> English in pronunciation and spelling.
4. Jim never got to work late, <u>did</u> <u>Jane</u>? (完成反意疑问句)
5. I am old enough and I can wear w<u>hatever</u> I like.
6. Our parents take p<u>ride</u> in everything good we do.
7. My parents are always <u>thinking of</u> me even though they are busy with their work.
8. The road to <u>success</u> (succeed) is always difficult. So don't give up until you make your dream come true.
9. Mr. White doesn't know whether his son <u>has dealt with</u> (`deal with`) the problem so far.

---

#### Test for Unit 4 错题

1. I think we need to improve our educational system in <u>general</u> (总的).
2. The teacher <u>advised</u> (建议) the parents to talk with the kid in person.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

### Unit 5 What are the shirts made of?

---

#### 全效学习错题

1. Sweaters may <u>be produced</u> (produce) in many different ways.
2. Butter is made <u>from</u> milk.
3. It is well-known <u>to</u> most people that Beijing is known as the capital of China.
4. When you visit F<u>rance</u>, you can go to the Eiffel Tower and take photos there.
5. This kind of cars <u>is produced</u> (produce) in China.
6. Students <u>aren't allowed</u> to take smartphones to school.
7. Those terrible accidents <u>were caused</u> by the careless drivers last year.
8. Jack usually washes the car on Sunday.<br>
   The car <u>is</u> usually washed by Jack on Sunday.
9. 看看哪只风筝飞得最高是件很有趣的事情。<br>
   It's really fun to <u>see</u> which kite flies the highest.
10. The water can be h<u>eated</u> to become gas.
11. I can't play soccer with you now because I have to c<u>omplete</u> my homework first.
12. Jane tries to avoid <u>meeting</u> (meet) her cousin because he always makes her bored.
13. Most of the <u>products</u> (product) are American products, but they are made in China.
14. Usually, the most common things can <u>be turned into</u> (`turn info`) objects of beauty.
15. Weifang, a city in Shandong Province, <u>has been known for</u> (`be known for`) making kites _since_ over 2,000 years ago.

---

#### Test for Unit 5 错题

1. The telephone was invented <u>in 1876</u>. (划线提问)<br>
    <u>When</u> was the telephone invented?

---

#### 全效·基础循环练错题

---

#### 周周清错题

---

<div class="divider"></div>

<script setup>
import { ref } from "vue";

const printTitle = ref(decodeURI(new URL(location.href).pathname.split("/")[1])) ?? "政史地总资料";

const documentTitle = ref(decodeURI(new URL(location.href).pathname.split("/").filter(x => (x !== "" && x !== "print")).join(" | "))) ?? "政史地总资料";

const printDate = ref(`导出日期：${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`);

</script>

# 版权声明

作者: [7086cmd](https://github.com/7086cmd).<br>

<p style="font-size: 24px">
本文遵循 <code>CC BY-NC-SA 4.0</code> 协议。未经允许，请勿擅自改动、商用这些内容，并且若转载请注明出处。
</p>

<div class="center">
  <div id="ending">7086cmd's notes</div>
</div>

<div class="right">
  <p>未经作者许可禁售。</p>
</div>
