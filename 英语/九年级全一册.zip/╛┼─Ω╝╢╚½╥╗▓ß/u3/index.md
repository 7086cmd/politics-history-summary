### Unit 3 Could you please tell me where are the restrooms are?

---

#### 全效学习错题

1. I beg your p<u>ardon</u>, sir. How will you deal with the problem?
2. Could you please tell me the way to the post office? I want to buy some <u>stamps</u> (邮票).
3. The doctor s<u>uggests</u> we should eat more vegetables and do sports.
4. The little girl is nervous, so she <u>holds</u> (抓住) her mother's hands wherever they go.
5. When the girl saw the snake, she was very <u>scared</u> (scare).
6. I suggest <u>going</u> (go) to the Fun Times Park this weekend.
7. They <u>mailed</u> (邮寄) letters to their fathers to show thanks to them yesterday.
8. We all know the sum always rises in the e<u>ast</u> every morning.
9. "Why are you late?" the teacher asked him.<br>
   The teacher asked him why he <u>was</u> late.
10. Are there any public washrooms around here? She wanted to know.<br>
    She wanted to know if there <u>were</u> any public washrooms around here.
11. The young man is waiting for his friend at the c<u>orner</u> of Main Street.
12. The clerk s<u>uggests</u> the boy go to Green Land because they have delicious salads.
13. The big supermarket is <u>uncrowded</u> (crowd) on weekdays. Most people are busy with their work.
14. Anderson repeated his <u>request</u> (要求) that we put off the meeting.
15. <u>On their way to</u> (`on one's way to`) the farm，they met their English teacher.
16. More and more people like to buy books on the Internet as the books on the Internet are <u>inexpensive</u> (`expensive`).

---

#### Test for Unit 3 错题

1. \- Where are you going for the coming winter vacation?<br>\- I won't decide on the place <u>until</u> the end of this month. (`A`)<br>A. `until`<br>B. `unless`<br>C. `at`<br>D. `through`
2. \- I am very sad after hearing the earthquake of Yushu. But I don't know <u>what to do</u>.<br>\- You can raise your money to the charity.<br>A. `how I shoud do`<br>B. `how to do`<br>C. `what to do`<br>D. `what should I do`
3. To my surprise, my hometown <u>has changed</u> a lot in the past two years. (`B`)<br>A. `had changed`<br>B. `has changed`<br>C. `have changed`<br>D. `changed`
4. The boy said he often <u>played</u> soccer after school.

---

#### 全效·基础循环练错题

---

#### 周周清错题

<iframe src="./%E5%91%A8%E5%91%A8%E6%B8%85%E9%94%99%E9%A2%98.pdf" frameborder="0" width="100%" type="application/pdf"></iframe>

---
