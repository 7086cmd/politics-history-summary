### Unit 6 When was it invented?

---

#### 全效学习错题

1. How many products <u>are mentioned</u> (mention) in the passage?
2. He seems <u>to know</u> (know) the truth, but he won't tell us.
3. The Russian soup s<u>mells</u> very nice. I can't wait to enjoy it.
4. The water is <u>boiling</u>. Please shut off the gas.
5. They clean their machine three times a day.<br>
    Their machine <u>is</u> cleaned by them three times a day.
6. He bought a sweater yesterday.<br>
    A sweater <u>was</u> bought by him yesterday.
7. Our teachers gave me some books.<br>
    I was given some books by our teachers.
    Some books <u>were</u> given to me by our teachers.
8. Many beautiful lanterns <u>are bought</u> (buy) for the children last New Year.
9. There are a lot of national <u>heroes</u> (英雄) in Chinese history. Yuan Longping was one of them.

---

#### Test for Unit 6 错题

1. It's <u>pleasant</u> for me to see you. (`D`)<br>A. please<br>B. pleasure<br>C. pleased<br>D. pleasant
2. I need an <u>instrument</u> (工具，仪器) to finish this task.

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
