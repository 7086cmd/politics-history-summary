### Unit 7 Teenagers should be allowed to choose ther own clothes.

---

#### 全效学习错题

1. This weekend, I'm going to get my hair <u>cut</u> (cut).
2. I don't think students under 18 should be allowed to have their ears <u>pierced</u> (pierce).
3. Sixteen-year-olds should not be allowed to drive. They are not serious <u>enough</u>.
4. The little girl is too young to l<u>ift</u> that heavy box alone. Let's help her.
5. The woman could only speak a little Chinese, but she m<u>anaged</u> to make herself understood.
6. Lots of parents encourage their children to <u>make their own decisions</u>. (`make one's own decision`)
7. If you explain whant <u>happened</u> (happen), I think your teacher will understand.
8. Teenagers should get enough <u>support</u> (支持) from their parents.
9. "We have nothing <u>against</u> (反对), doing exercise. You can do it after finishing your homework," Mom said.
10. She <u>is</u> always <u>serious about</u> her work. We should learn from her. (`be serious about`)
11. Our English teacher is strict with us and she is also very strict <u>in</u> her work.
12. The villagers are against <u>building</u> (build) a new factory in their village.
13. The boy <u>was hugged</u> by his mother when he was found at the corner.

---

#### Test for Unit 7 错题

1. He enters (进入) the room quietly without disturbing (打扰) others.
2. As teenagers, we should make our <u>chioces</u> (选择).

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
