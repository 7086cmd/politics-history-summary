### Unit 10 You're supposed to shake hands.

---

#### 全效学习错题

1. Little Tom is used to k<u>issing</u> his mother on the face every night before going to bed.
2. Everyone except Mary <u>was invited</u> to the party last week.
3. My mother got m<u>ad</u> at me for coming home late last night.
4. I want to visit the western <u>coast</u> (海岸) of England during the summer holiday.
5. The customs in <u>Eastern</u> counties are dirrerent from those in <u>Western</u> countries.
6. In Korea, the <u>youngest</u> person is expected to start eating last.
7. The little boy is punished by his parents because he <u>stuck</u> the chopsticks <u>into</u> his food just now. (`stick into`)
8. That old woman often <u>points at</u> others angrily although it's her fault.
9. The book mainly tells you how to <u>behave</u> (表现) at the dinner table.
10. I'm very comfortable <u>speaking</u> (讲) English now with your help.
11. The man <u>made an effort</u> to succeed no matter what difficulties he met. (`go out of one's way`, `make an effort`)
12. When I am in trouble, my friends always <u>go out of their way</u> to help me get out of the trouble. (`go out of one's way`, `make an effort`)
13. The plane will <u>take off</u> from Beijing and land in London. (`take off`)

---

#### Test for Unit 10 错题

---

#### 全效·基础循环练错题

---

#### 周周清错题

---
